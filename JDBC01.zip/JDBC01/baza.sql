/*
SQLyog Community v13.1.1 (64 bit)
MySQL - 10.1.35-MariaDB : Database - njtjdbc
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`njtjdbc` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `njtjdbc`;

/*Table structure for table `proizvod` */

DROP TABLE IF EXISTS `proizvod`;

CREATE TABLE `proizvod` (
  `IDProizvod` int(11) NOT NULL,
  `naziv` varchar(30) DEFAULT NULL,
  `cena` double DEFAULT NULL,
  `IDProizvodjaca` int(11) DEFAULT NULL,
  PRIMARY KEY (`IDProizvod`),
  KEY `IDProizvodjaca` (`IDProizvodjaca`),
  CONSTRAINT `proizvod_ibfk_1` FOREIGN KEY (`IDProizvodjaca`) REFERENCES `proizvodjac` (`IDProizvodjac`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `proizvod` */

/*Table structure for table `proizvodjac` */

DROP TABLE IF EXISTS `proizvodjac`;

CREATE TABLE `proizvodjac` (
  `IDProizvodjac` int(11) NOT NULL,
  `naziv` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`IDProizvodjac`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `proizvodjac` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
